module.exports = {
    secret: "SECRET_RANDOM_KEY"
}